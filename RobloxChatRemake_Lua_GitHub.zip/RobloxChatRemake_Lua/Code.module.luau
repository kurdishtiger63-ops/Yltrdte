local module = {}

local codeTable1 = {}
local codeTable2 = {}
local length = 1

module.setCodeTable = function(list, newLength)
	codeTable1 = list
	codeTable2 = {}
	for key, value in list do
		codeTable2[value] = key
	end
	length = newLength
end

module.encode = function(text: string)
	text = text:reverse()
	local encoded = ""
	local something_wrong = false
	for i = 1, #text do
		local char = codeTable1[text:sub(i, i)]
		if char then
			encoded ..= char:reverse()
		elseif not something_wrong then
			something_wrong = true
			warn("[ExpChatRemake]: WARNING! Some characters may not appear in the message because they were not found in the code table.")
		end
	end
	return buffer.fromstring(encoded:reverse())
end

module.decode = function(buff: buffer)
	local text = buffer.tostring(buff):reverse()
	local decoded = ""
	for i = 1,math.floor(#text/length) do
		decoded ..= codeTable2[text:sub(i*length-(length-1),i*length):reverse()] or ""
	end
	return decoded:reverse()
end

return module