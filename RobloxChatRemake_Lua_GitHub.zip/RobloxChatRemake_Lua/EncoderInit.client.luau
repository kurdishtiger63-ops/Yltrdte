script.Parent = nil

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local code = ReplicatedStorage:WaitForChild("Code")
local remote = ReplicatedStorage:WaitForChild("giveclient")
shared.code = require(code)
code.Parent = nil
remote.Parent = nil

remote.OnClientInvoke = function(list, length)
	shared.code.setCodeTable(list, length)
end