if not game:IsLoaded() then
	game.Loaded:Wait()
end

script.Parent = nil

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local TextChatService = game:GetService("TextChatService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local NOTRBXGeneral = TextChatService:WaitForChild("NOTRBXGeneral")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local ComputeNameColor = require(Modules:WaitForChild("NameColor"))

while not shared.code do
	task.wait()
end

local decode = shared.code.decode

Remotes:WaitForChild("Event").OnClientEvent:Connect(function(player, message, player2, team, icon)
	message = decode(message)
	player = Players:FindFirstChild(decode(player))
	player2 = (player2 and Players:FindFirstChild(decode(player2))) or team
	local C = player.Team and player.TeamColor.Color or ComputeNameColor(player.Name)
	local RGB = `#{C:ToHex()}`
	NOTRBXGeneral:DisplaySystemMessage(`<font color="{RGB}">{player2 and (player2:IsA("Team") and `[Team] ` or `</font>[{player2 == LocalPlayer and `From {player.DisplayName}` or `To {player2.DisplayName}`}] <font color="{RGB}">`) or ""}{player.DisplayName}{icon and `<font family="rbxasset://LuaPackages/Packages/_Index/BuilderIcons/BuilderIcons/BuilderIcons.json" color="#ffffff">{icon}</font>` or ""}{player.MembershipType == Enum.MembershipType.Premium and utf8.char(0xE001) or ""}{player.HasVerifiedBadge and utf8.char(0xE000) or ""}:</font>!!separator!! {message}`, player.Name)
	if player.Character and message ~= "" then
		TextChatService:DisplayBubble(player.Character, message)
	end
end)

Remotes:WaitForChild("DisplaySystem").OnClientEvent:Connect(function(message, metadata)
	NOTRBXGeneral:DisplaySystemMessage(decode(message), metadata and decode(metadata) or "")
end)

Remotes:WaitForChild("Fire").Event:Connect(function(command)
	NOTRBXGeneral:SendAsync(command)
end)

game:GetService("RunService").RenderStepped:Connect(function()
	TextChatService:WaitForChild("ChatWindowConfiguration").Enabled = false
	TextChatService:WaitForChild("ChatInputBarConfiguration").Enabled = false
end)

while not LocalPlayer.PlayerGui:FindFirstChild("Experience") and not LocalPlayer.PlayerGui:FindFirstChild("FakeExperience") do
	Remotes:WaitForChild("CreateUI"):InvokeServer()
	task.wait(0.1)
end