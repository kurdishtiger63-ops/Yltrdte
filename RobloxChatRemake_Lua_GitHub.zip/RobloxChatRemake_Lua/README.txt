RobloxChatRemake - extracted Luau sources

These files were extracted from the supplied RobloxChatRemake.rbxm model.
Original instance names are reflected in the filenames.

IMPORTANT:
- This is a source extraction, not a ready-to-run GitHub package.
- The model also contains UI instances and other Roblox objects that are not represented as Luau files here.
- Review the README_IMPORTANT.luau and each script before installing.
- Do not publish private keys, tokens, or personal information.
- GitHub repository upload does not install the scripts into a Roblox experience.
