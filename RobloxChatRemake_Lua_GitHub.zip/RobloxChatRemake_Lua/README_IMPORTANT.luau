--]
---
░█████╗░██╗░░██╗░█████╗░████████╗  ██████╗░███████╗███╗░░░███╗░█████╗░██╗░░██╗███████╗
██╔══██╗██║░░██║██╔══██╗╚══██╔══╝  ██╔══██╗██╔════╝████╗░████║██╔══██╗██║░██╔╝██╔════╝
██║░░╚═╝███████║███████║░░░██║░░░  ██████╔╝█████╗░░██╔████╔██║███████║█████═╝░█████╗░░
██║░░██╗██╔══██║██╔══██║░░░██║░░░  ██╔══██╗██╔══╝░░██║╚██╔╝██║██╔══██║██╔═██╗░██╔══╝░░
╚█████╔╝██║░░██║██║░░██║░░░██║░░░  ██║░░██║███████╗██║░╚═╝░██║██║░░██║██║░╚██╗███████╗
░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░  ╚═╝░░╚═╝╚══════╝╚═╝░░░░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝

--How to Set it up:-

--1. Put the "ReplicatedFirst" in ReplicatedFirst And ungroup.

--2. Put the "ReplicatedStorage" in replicatedStorage and ungroup.

--3. Put the "ServerScriptService" in ServerScriptService and ungroup.

-- IMPORTANT!!!

-- Go to TextChatService properties and set "CreateDefaultTextChannel" to false
-- OR ELSE IT WONT WORK!!


-- Whats the point of this chat? 🤔

-- The point of this chat system is allow players from all age groups and all regions talk without restrictions.





-- 
███╗░░░███╗░█████╗░░█████╗░░██████╗░█████╗░░██████╗░██████╗░███████╗░█████╗░████████╗
████╗░████║██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔════╝░██╔══██╗██╔════╝██╔══██╗╚══██╔══╝
██╔████╔██║██║░░██║██║░░██║╚█████╗░███████║██║░░██╗░██████╔╝█████╗░░███████║░░░██║░░░
██║╚██╔╝██║██║░░██║██║░░██║░╚═══██╗██╔══██║██║░░╚██╗██╔══██╗██╔══╝░░██╔══██║░░░██║░░░
██║░╚═╝░██║╚█████╔╝╚█████╔╝██████╔╝██║░░██║╚██████╔╝██║░░██║███████╗██║░░██║░░░██║░░░
╚═╝░░░░░╚═╝░╚════╝░░╚════╝░╚═════╝░╚═╝░░╚═╝░╚═════╝░╚═╝░░╚═╝╚══════╝╚═╝░░╚═╝░░░╚═╝░░░

	







































































local script = game:FindFirstChild("README_FIRST_EXPCHATREMAKE!@#$%^&*()_+=-:;'\"[]{}<>,./?\\|`~", true)
local folder = script.Parent
for _, service in folder:GetChildren() do
	if service:IsA("Folder") then
		for _, inst in service:GetChildren() do
			inst.Parent = game:GetService(service.Name)
		end
	end
end
folder:Destroy()