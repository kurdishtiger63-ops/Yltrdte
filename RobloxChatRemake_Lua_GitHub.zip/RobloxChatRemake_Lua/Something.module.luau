local Players = game:GetService("Players")
local TextChatService = game:GetService("TextChatService")
local FireCommand = game:GetService("ReplicatedStorage"):WaitForChild("Remotes"):WaitForChild("Fire")
local Commands = {}
local IsClient = game:GetService("RunService"):IsClient()
local ClientCommands = {}

if IsClient then
	ClientCommands = {
		RBXCustomHelpCommand = function()
			TextChatService:WaitForChild("NOTRBXGeneral"):DisplaySystemMessage('<font color="#d4d4d4">/clear -- clear chat\n/whisper [player] [message] -- send private message to speaker\n/team [message] -- send message for your team\n/console -- open developer console\n/emote [emote name] -- play emote\n/mute [player name] -- mute player\n/unmute [player name] -- unmute player</font>')
		end,
		NOTRBXfreekorbloxrealfrfr = function()
			if Players.LocalPlayer.Character and not Players.LocalPlayer.Character:GetAttribute("tfilcommand") then
				Players.LocalPlayer.Character:SetAttribute("tfilcommand", true)
				task.wait(1.5)
				shared.triggerTCH("free korblox? ok wait a sec", nil, "Client")
			end
		end,
	}
end

local function addcommand(TextChatCommand: TextChatCommand)
	--print('Command', TextChatCommand.Name)
	Commands[#Commands+1] = {
		TextChatCommand = TextChatCommand,
		PrimaryAlias = TextChatCommand.PrimaryAlias,
		SecondaryAlias = TextChatCommand.SecondaryAlias
	}
	if IsClient and ClientCommands[TextChatCommand.Name] then
		TextChatCommand.Triggered:Connect(ClientCommands[TextChatCommand.Name])
	end
end

TextChatService.DescendantAdded:Connect(function(TextChatCommand)
	if TextChatCommand:IsA("TextChatCommand") then
		addcommand(TextChatCommand)
	end
end)

TextChatService.DescendantRemoving:Connect(function(TextChatCommand)
	if TextChatCommand:IsA("TextChatCommand") then
		--warn('Command', TextChatCommand.Name)
		for I, Command in Commands do
			if Command.TextChatCommand == TextChatCommand then
				table.remove(Commands, I)
			end
		end
	end
end)

for _, TextChatCommand in TextChatService:WaitForChild("TextChatCommands"):GetChildren() do
	if TextChatCommand:IsA("TextChatCommand") then
		addcommand(TextChatCommand)
	end
end

return {
	function(message)
		local split = message:split(" ")
		local command = split[1]
		local message = table.concat(split, " ", 2)
		for _, Command in Commands do
			if command == Command.PrimaryAlias or command == Command.SecondaryAlias then
				FireCommand:Fire(`{command} {message}`)
				return Command.TextChatCommand
			end
		end
		return nil
	end, 
	function(message)
		local split = message:split(" ")
		if split[1]:sub(1,1) == "/" then
			for _, Command in Commands do
				if split[1] == Command.PrimaryAlias or split[1] == Command.SecondaryAlias then
					return true
				end
			end
		end
		return false
	end
}