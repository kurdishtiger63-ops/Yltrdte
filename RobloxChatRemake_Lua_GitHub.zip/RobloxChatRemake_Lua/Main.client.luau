local UI = script.Parent
local received_template = script.Received
local systemreceived_template = script.SystemReceived
local autocomplete_template = script.Autocomplete
local emojiautocomplete_template = script.EmojiAutocomplete

script.Parent = nil

local focused = false
local oc = os.clock()+3
local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local TextChatService = game:GetService("TextChatService")
local TweenService = game:GetService("TweenService")
local StarterGui = game:GetService("StarterGui")
local RunService = game:GetService("RunService")
local Messages = {}
local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local send = Remotes:WaitForChild("Update")
local ping = Remotes:WaitForChild("Ping")
local typingchange = Remotes:WaitForChild("TypingChanged")
local ComputeNameColor = require(Modules:WaitForChild("NameColor"))
local TextChatCommands = require(Modules:WaitForChild("Something"))
local EmojiList = require(Modules:WaitForChild("EmojiList"))
local CWC = TextChatService:WaitForChild("ChatWindowConfiguration")
local CIBC = TextChatService:WaitForChild("ChatInputBarConfiguration")
local appLayout = UI.appLayout
local RCTScrollContentView = appLayout.window.scrollingView.bottomLockedScrollView.RCTScrollView.RCTScrollContentView
local TextContainer = appLayout.inputBar.Background.Container.TextContainer
local Textbox = TextContainer.TextBoxContainer.TextBox
local Typing = appLayout.someStuff.TypingText
local TargetChannelChip = TextContainer.TargetChannelChip
local muted = false
local cstatus, cstatusdata = "All", nil
local execCmd, isCmd = TextChatCommands[1], TextChatCommands[2]
local defaultSize = appLayout.Size
local placeholderText = ""
local peopleTypingRn = {}
local encode = shared.code.encode

local WHITESPACES = {
	"\n\r\t\v\f",
	{
		["\n"] = " ",
		["\r"] = " ",
		["\t"] = " ",
		["\v"] = " ",
		["\f"] = " "
	}
}
local REPLACE = {
	`&<>"'`,
	{
		["&"] = "&amp;",
		["<"] = "&lt;",
		[">"] = "&gt;",
		['"'] = '&quot;',
		["'"] = '&apos;',
	}
}

local function lerp(a, b, c)
	return a + (b - a) * c
end

local function textSet(TextGui, Config)
	if typeof(TextGui) ~= "Instance" or not (TextGui:IsA("TextLabel") or TextGui:IsA("TextBox") or TextGui:IsA("TextButton")) then
		return
	end
	if Config ~= CWC and Config ~= CIBC then
		return
	end
	TextGui.FontFace = Config.FontFace
	TextGui.TextColor3 = Config.TextColor3
	TextGui.TextSize = Config.TextSize*(TextGui == Typing and 14/18 or 1)
	TextGui.TextStrokeColor3 = Config.TextStrokeColor3
	TextGui.TextStrokeTransparency = Config.TextStrokeTransparency
	if Config == CIBC then
		TextGui.PlaceholderColor3 = Config.PlaceholderColor3
	end
end

local function log(TextChannel)
	if TextChannel:IsA("TextChannel") then
		--print('Channel', TextChannel.Name)
		TextChannel.MessageReceived:Connect(function(TextChatMessage: TextChatMessage)
			local metadata, message = TextChatMessage.Metadata, nil
			local player = Players:FindFirstChild(metadata)
			if player then
				message = received_template:Clone()
			else
				message = systemreceived_template:Clone()
			end
			Messages[#Messages+1] = message
			if player then
				local textmessage = message.TextMessage
				local metadata = TextChatMessage.Metadata
				local split = TextChatMessage.Text:split("!!separator!!")
				local prefix, bodytext = split[1], split[2]
				textmessage.PrefixText.Text = prefix
				textmessage.BodyText.Text = `<font transparency='1.0'><stroke transparency='1.0'>{prefix}</stroke></font>`..bodytext
				local textbutton = textmessage.TextMessageButton.TextButton
				if player ~= LocalPlayer then
					textbutton.MouseButton1Click:Connect(function()
						if player.Parent then
							Textbox.Text = `/w {player.Name} `
						end
					end)
				end
				textbutton.Text = prefix
				message.Name = TextChatMessage.MessageId:gsub("0", `{player.UserId}`, 1)
				textSet(textbutton, CWC)
				textSet(textmessage.PrefixText, CWC)
				textSet(textmessage.BodyText, CWC)
			else
				local textmessage = message.TextMessage
				if metadata == "rgb" then
					local h = 0
					local c; c = RunService.RenderStepped:Connect(function(dt)
						if message.Parent then
							local cs = TextChatMessage.Text:split("")
							for i, cc in cs do
								local hue = (h+((i-1)*0.025))%1
								cs[i] = `<font color="#{Color3.fromHSV(hue,1,1):ToHex()}">{cc}</font>`
							end
							textmessage.BodyText.Text = table.concat(cs, "")
							h += dt
						else
							c:Disconnect()
						end
					end)
					message.Name = TextChatMessage.MessageId
				elseif metadata and metadata ~= "" and pcall(function() local colors = {} for _, color in metadata:split(",") do Color3.fromHex(color) end return colors end) then
					local colorsLerp = {}
					local colors = metadata:split(",")
					if #colors > 1 then
						table.insert(colorsLerp, Color3.fromHex(colors[1]))
						for i = 1, #colors-1, 1 do
							local from, to = Color3.fromHex(colors[i]), Color3.fromHex(colors[i+1])
							for e = 1, 10 do
								table.insert(colorsLerp, Color3.new(lerp(from.R, to.R, e/10), lerp(from.G, to.G, e/10), lerp(from.B, to.B, e/10)))
							end
						end
						local from, to = colorsLerp[#colorsLerp], colorsLerp[1]
						for e = 1, 10 do
							table.insert(colorsLerp, Color3.new(lerp(from.R, to.R, e/10), lerp(from.G, to.G, e/10), lerp(from.B, to.B, e/10)))
						end
						local h = 0
						local c; c = RunService.RenderStepped:Connect(function(dt)
							if message.Parent then
								local cs = TextChatMessage.Text:split("")
								for i, cc in cs do
									local hue = (h+(i-1))%(#colorsLerp-#colors-1)
									cs[i] = `<font color="#{colorsLerp[math.round(hue+1)]:ToHex()}">{cc}</font>`
								end
								textmessage.BodyText.Text = table.concat(cs, "")
								h += 30*dt
							else
								c:Disconnect()
							end
						end)
						message.Name = TextChatMessage.MessageId
					else
						textmessage.BodyText.Text = `<font color="{metadata:sub(1,1) == "#" and metadata or `#{metadata}`}">{TextChatMessage.Text}</font>`
						message.Name = TextChatMessage.MessageId
					end
				else
					textmessage.BodyText.Text = TextChatMessage.Text
					message.Name = TextChatMessage.MessageId
				end
				textSet(textmessage.BodyText, CWC)
			end
			message.Parent = RCTScrollContentView
			if #Messages > 100 then
				Messages[1]:Destroy()
				table.remove(Messages, 1)
			end
		end)
	end
end

TextChatService.DescendantAdded:Connect(log)

for _, TextChannel in TextChatService:GetDescendants() do
	log(TextChannel)
end

local function CWCChanged()
	pcall(function()
		appLayout.Size = UDim2.fromScale(defaultSize.X.Scale*CWC.WidthScale, defaultSize.Y.Scale*CWC.HeightScale)
		appLayout.window.BackgroundColor3 = CWC.BackgroundColor3
		appLayout.topBorder.ImageColor3 = CWC.BackgroundColor3
		appLayout.bottomBorder.ImageColor3 = CWC.BackgroundColor3
		appLayout.topPadding.BackgroundColor3 = CWC.BackgroundColor3
		appLayout.inputBar.BackgroundColor3 = CWC.BackgroundColor3
		appLayout.someStuff.BackgroundColor3 = CWC.BackgroundColor3
		if os.clock() <= oc then
			appLayout.window.BackgroundTransparency = CWC.BackgroundTransparency
			appLayout.topBorder.ImageTransparency = CWC.BackgroundTransparency
			appLayout.bottomBorder.ImageTransparency = CWC.BackgroundTransparency
			appLayout.topPadding.BackgroundTransparency = CWC.BackgroundTransparency
			appLayout.inputBar.BackgroundTransparency = CWC.BackgroundTransparency
			appLayout.someStuff.BackgroundTransparency = CWC.BackgroundTransparency
		end

		local AP = appLayout.AnchorPoint
		local Pos = appLayout.Position

		if CWC.HorizontalAlignment == Enum.HorizontalAlignment.Left then
			appLayout.AnchorPoint = Vector2.new(0, AP.Y)
			appLayout.Position = UDim2.new(0, 8, Pos.Y.Scale, Pos.Y.Offset)
		elseif CWC.HorizontalAlignment == Enum.HorizontalAlignment.Center then
			appLayout.AnchorPoint = Vector2.new(0.5, AP.Y)
			appLayout.Position = UDim2.new(0.5, 0, Pos.Y.Scale, Pos.Y.Offset)
		elseif CWC.HorizontalAlignment == Enum.HorizontalAlignment.Right then
			appLayout.AnchorPoint = Vector2.new(1, AP.Y)
			appLayout.Position = UDim2.new(1, -8, Pos.Y.Scale, Pos.Y.Offset)
		end

		if CWC.VerticalAlignment == Enum.VerticalAlignment.Top then
			appLayout.AnchorPoint = Vector2.new(AP.X, 0)
			appLayout.Position = UDim2.new(Pos.X.Scale, Pos.X.Offset, 0, 4)
		elseif CWC.VerticalAlignment == Enum.VerticalAlignment.Center then
			appLayout.AnchorPoint = Vector2.new(AP.X, 0.5)
			appLayout.Position = UDim2.new(Pos.X.Scale, Pos.X.Offset, 0.5, 0)
		elseif CWC.VerticalAlignment == Enum.VerticalAlignment.Bottom then
			appLayout.AnchorPoint = Vector2.new(AP.X, 1)
			appLayout.Position = UDim2.new(Pos.X.Scale, Pos.X.Offset, 1, -4)
		end

		textSet(Typing, CWC)

		for _, message in Messages do
			textSet(message:FindFirstChild("TextButton", true), CWC)
			textSet(message:FindFirstChild("PrefixText", true), CWC)
			textSet(message:FindFirstChild("BodyText", true), CWC)
		end
	end)
end

local function CIBCChanged()
	pcall(function()
		CIBC.TextBox = nil
		appLayout.inputBar.Background.BackgroundColor3 = CIBC.BackgroundColor3
		if os.clock() <= oc then
			appLayout.inputBar.Background.BackgroundTransparency = CIBC.BackgroundTransparency
		end
		textSet(Textbox, CIBC)
	end)
end

CWC.Changed:Connect(CWCChanged)
CIBC.Changed:Connect(CIBCChanged)
CWCChanged()
CIBCChanged()

CWC.AttributeChanged:Connect(function()
	pcall(function()
		appLayout.window.Visible = CWC:GetAttribute("CustomEnabled")
	end)
end)
CIBC.AttributeChanged:Connect(function()
	pcall(function()
		if muted then
			appLayout.inputBar.Visible = false
		else
			appLayout.inputBar.Visible = CIBC:GetAttribute("CustomEnabled")
		end
	end)
end)

TextChatService:WaitForChild("TextChatCommands"):WaitForChild("RBXClearCommand").Triggered:Connect(function()
	for _, message in RCTScrollContentView:GetChildren() do
		if message:IsA("Frame") then
			message:Destroy()
		end
	end
	Messages = {}
end)

local function CheckMessage(text)
	text = text:gsub(`[{WHITESPACES[1]}]`, WHITESPACES[2])
	text = text:gsub(`[{REPLACE[1]}]`, REPLACE[2])
	local text = (text):split(" ")
	local whatrm = {}
	for index, _ in text do
		if text[index] == "" then
			whatrm[#whatrm+1] = index
		end
	end
	local lol = 0
	for _, index in whatrm do
		table.remove(text, index-lol)
		lol += 1
	end
	return table.concat(text, " ")
end

local function GetPlayer(name: string)
	name = name:lower()
	local players = {}
	for _, player in Players:GetPlayers() do
		if player == LocalPlayer then continue end
		if player.DisplayName:lower():sub(1,name:len()) == name or player.Name:lower():sub(1,name:len()) == name then
			players[#players+1] = player
		end
	end
	return #players == 1 and players[1]
end

local function clientsend(msg)
	local correctedmsg = CheckMessage(msg)
	if correctedmsg == "" or correctedmsg:gsub(" ", "") == "" or #correctedmsg > 200 or muted then return end
	local C = not LocalPlayer.Neutral and LocalPlayer.TeamColor.Color or ComputeNameColor(LocalPlayer.Name)
	local message = received_template:Clone()
	local prefix = `<font color="#{C:ToHex()}">{(typeof(cstatusdata) == "Instance" and cstatusdata:IsA("Player") and `</font>[{cstatus}] <font color="#{C:ToHex()}">`) or (cstatus ~= "All" and `[{cstatus}] `) or ""}{LocalPlayer.DisplayName}{LocalPlayer:GetAttribute("IconInChat") and `<font family="rbxasset://LuaPackages/Packages/_Index/BuilderIcons/BuilderIcons/BuilderIcons.json" color="#ffffff">{LocalPlayer:GetAttribute("IconInChat")}</font>` or ""}{LocalPlayer.HasVerifiedBadge and utf8.char(0xE000) or ""}:</font>`
	message.LayoutOrder = 2
	message.TextMessage.PrefixText.TextTransparency = 0.375
	message.TextMessage.BodyText.TextTransparency = 0.375
	message.TextMessage.PrefixText.Text = prefix
	message.TextMessage.BodyText.Text = `<font transparency='1.0'><stroke transparency='1.0'>{prefix}</stroke></font> {correctedmsg}`
	message.Name = "__tmp_msg"
	textSet(message:FindFirstChild("TextButton", true), CWC)
	textSet(message:FindFirstChild("PrefixText", true), CWC)
	textSet(message:FindFirstChild("BodyText", true), CWC)
	message.Parent = appLayout:WaitForChild("window").scrollingView.bottomLockedScrollView.RCTScrollView.RCTScrollContentView
	task.spawn(function()
		local emsg = encode(msg)
		if cstatus == "All" then
			send:InvokeServer(emsg)
		elseif cstatus == "Team" then
			execCmd(`/team {msg}`)
			ping:InvokeServer(emsg)
		elseif typeof(cstatusdata) == "Instance" and cstatusdata:IsA("Player") then
			execCmd(`/w {cstatusdata.Name} {msg}`)
			ping:InvokeServer(emsg)
		end
		message:Destroy()
	end)
	return true
end

Remotes:WaitForChild("StatusChanged").OnClientEvent:Connect(function(status)
	muted = status
	if not muted then
		Textbox.Text = ""
	end
end)

local sendi = appLayout:WaitForChild("inputBar").Background.Container.SendButton.SendIcon
local ShowInfo = TweenInfo.new(0)
local HideInfo = TweenInfo.new(0.7, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)

local Show = {
	TweenService:Create(appLayout:WaitForChild("window"), ShowInfo, {BackgroundTransparency = CWC.BackgroundTransparency}),
	TweenService:Create(appLayout:WaitForChild("inputBar"), ShowInfo, {BackgroundTransparency = CWC.BackgroundTransparency}),
	TweenService:Create(appLayout.topPadding, ShowInfo, {BackgroundTransparency = CWC.BackgroundTransparency}),
	TweenService:Create(appLayout.bottomBorder, ShowInfo, {ImageTransparency = CWC.BackgroundTransparency}),
	TweenService:Create(appLayout.topBorder, ShowInfo, {ImageTransparency = CWC.BackgroundTransparency}),
	TweenService:Create(appLayout:WaitForChild("inputBar").Background, ShowInfo, {BackgroundTransparency = CIBC.BackgroundTransparency}),
	TweenService:Create(appLayout:WaitForChild("inputBar").Background.Border, ShowInfo, {Transparency = 0.8}),
	TweenService:Create(appLayout:WaitForChild("window").scrollingView.bottomLockedScrollView.RCTScrollView, ShowInfo, {ScrollBarImageTransparency = 0.3}),
	TweenService:Create(TargetChannelChip, ShowInfo, {TextTransparency = 0}),
	TweenService:Create(Typing.Parent, ShowInfo, {BackgroundTransparency = CWC.BackgroundTransparency}),
}
local Hide = {
	TweenService:Create(appLayout:WaitForChild("window"), HideInfo, {BackgroundTransparency = 1}),
	TweenService:Create(appLayout:WaitForChild("inputBar"), HideInfo, {BackgroundTransparency = 1}),
	TweenService:Create(appLayout.topPadding, HideInfo, {BackgroundTransparency = 1}),
	TweenService:Create(appLayout.bottomBorder, HideInfo, {ImageTransparency = 1}),
	TweenService:Create(appLayout.topBorder, HideInfo, {ImageTransparency = 1}),
	TweenService:Create(appLayout:WaitForChild("inputBar").Background, HideInfo, {BackgroundTransparency = 1}),
	TweenService:Create(appLayout:WaitForChild("inputBar").Background.Border, HideInfo, {Transparency = 1}),
	TweenService:Create(appLayout:WaitForChild("window").scrollingView.bottomLockedScrollView.RCTScrollView, HideInfo, {ScrollBarImageTransparency = 1}),
	TweenService:Create(Textbox, HideInfo, {TextTransparency = 1, TextStrokeTransparency = 1}),
	TweenService:Create(sendi, HideInfo, {TextTransparency = 1}),
	TweenService:Create(TargetChannelChip, HideInfo, {TextTransparency = 1}),
	TweenService:Create(Typing.Parent, HideInfo, {BackgroundTransparency = 1}),
}

local ddinfo = {}
local dd = appLayout:WaitForChild("inputBar").AutocompleteDropdown
local uhh = dd.ScrollBarFrame.ScrollViewFrame.ScrollView.OffsetFrame
local selected = nil

local function selectindex(index)
	print(selected, index)
	local info = ddinfo[index]
	if info then
		local ac = info[2]
		if typeof(ac) == "Instance" then
			for _, info in ddinfo do
				info[2].TextLabelButton.BackgroundTransparency = 1
			end
			ac.TextLabelButton.BackgroundTransparency = 0.85
			uhh.Parent.CanvasPosition = Vector2.new(0, uhh.Parent.CanvasPosition.Y + ac.AbsoluteSize.Y*(index-selected))
			selected = index
		end
	end
end

local function enter(lastColon, name)
	if selected then
		if lastColon ~= 0 then
			Textbox.Text = Textbox.Text:gsub(":"..name, EmojiList[ddinfo[selected][1]].base)
		else
			Textbox.Text = ddinfo[selected][1]
		end
		task.spawn(function()
			RunService.RenderStepped:Wait()
			Textbox:CaptureFocus()
		end)
	end
end

local function commandautocomplete()
	if not CIBC.AutocompleteEnabled then
		local layout = uhh["$layout"]:Clone()
		uhh:ClearAllChildren()
		layout.Parent = uhh
		dd.Visible = false
		ddinfo = {}
		selected = nil
		return
	end
	local lol = 0
	local layout = uhh["$layout"]:Clone()
	uhh:ClearAllChildren()
	layout.Parent = uhh
	ddinfo = {}
	for _, command in TextChatService:GetDescendants() do
		if command:IsA("TextChatCommand") and command.PrimaryAlias:lower():find(Textbox.Text:lower()) then
			lol += 1
			ddinfo[#ddinfo+1] = {command.PrimaryAlias, autocomplete_template:Clone(), Textbox.text:lower()}
		end
	end
	table.sort(ddinfo, function(a,b)
		return a[1]:lower() < b[1]:lower()
	end)
	for i, command in ddinfo do
		local ac = command[2]
		ac.Name = command[1]
		ac.TextLabelButton.TextLabel.Text = command[1]
		ac.TextLabelButton.MouseButton1Down:Connect(function()
			Textbox.Text = command[1]
			RunService.RenderStepped:Wait()
			Textbox:CaptureFocus()
			selected = nil
		end)
		ac.TextLabelButton.MouseEnter:Connect(function()
			for _, command in ddinfo do
				command[2].TextLabelButton.BackgroundTransparency = 1
			end
			ac.TextLabelButton.BackgroundTransparency = 0.85
			selected = i
		end)
		if i == 1 then
			ac.TextLabelButton.BackgroundTransparency = 0.85
			selected = i
		end
		ac.Parent = uhh
	end
	lol *= 30
	dd.Size = UDim2.new(0.95, 0, 0, (lol > 105 and 105 or lol))
	if lol <= 0 or (lol <= 30 and Textbox.Text:lower() == ddinfo[1][1]) then
		local layout = uhh["$layout"]:Clone()
		uhh:ClearAllChildren()
		layout.Parent = uhh
		dd.Visible = false
		ddinfo = {}
		selected = nil
	else
		dd.Visible = true
	end
end

local function textAfterLastColon(text: string)
	local lastColon = text:reverse():find(":")
	if lastColon then
		lastColon *= -1
		return text:sub(lastColon+1,#text):split(" ")[1]
	else
		return text
	end
end

local function emojiautocomplete(lastColon)
	if not CIBC.AutocompleteEnabled or lastColon == 0 then
		local layout = uhh["$layout"]:Clone()
		uhh:ClearAllChildren()
		layout.Parent = uhh
		dd.Visible = false
		ddinfo = {}
		selected = nil
		return
	end
	local len = #Textbox.Text
	local name = textAfterLastColon(Textbox.Text)
	if #name < 2 then
		local layout = uhh["$layout"]:Clone()
		uhh:ClearAllChildren()
		layout.Parent = uhh
		dd.Visible = false
		ddinfo = {}
		selected = nil
		return
	end
	local lol = 0
	local layout = uhh["$layout"]:Clone()
	uhh:ClearAllChildren()
	layout.Parent = uhh
	ddinfo = {}
	for emoji, info in EmojiList do
		if emoji:lower():sub(1,#name) == name:lower() then
			lol += 1
			ddinfo[#ddinfo+1] = {emoji, emojiautocomplete_template:Clone(), name}
		end
	end
	table.sort(ddinfo, function(a,b)
		return EmojiList[a[1]].popularity < EmojiList[b[1]].popularity
	end)
	for i, info in ddinfo do
		local ac = info[2]
		ac.Name = info[1]
		ac.TextLabelButton.EmojiLabel.Text = EmojiList[info[1]].base
		ac.TextLabelButton.TextLabel.Text = info[1]
		ac.TextLabelButton.MouseButton1Down:Connect(function()
			Textbox.Text = Textbox.Text:gsub(":"..name, EmojiList[ddinfo[selected][1]].base)
			RunService.RenderStepped:Wait()
			Textbox:CaptureFocus()
			selected = nil
		end)
		ac.TextLabelButton.MouseEnter:Connect(function()
			for _, info in ddinfo do
				info[2].TextLabelButton.BackgroundTransparency = 1
			end
			ac.TextLabelButton.BackgroundTransparency = 0.85
			selected = i
		end)
		if i == 1 then
			ac.TextLabelButton.BackgroundTransparency = 0.85
			selected = i
		end
		ac.Parent = uhh
	end
	lol *= 30
	dd.Size = UDim2.new(0.95, 0, 0, (lol > 105 and 105 or lol))
	if lol <= 0 or (lol <= 30 and Textbox.Text:lower() == ddinfo[1][1]) then
		local layout = uhh["$layout"]:Clone()
		uhh:ClearAllChildren()
		layout.Parent = uhh
		dd.Visible = false
		selected = nil
	else
		dd.Visible = true
	end
end

local function ChangeChatStatus(status: string, data: any)
	cstatus = status
	cstatusdata = data
	TargetChannelChip.Text = status == "All" and "" or `[{status}]`
	if TargetChannelChip.Text == "" then
		TargetChannelChip.Visible = false
		Textbox.Parent.Size = UDim2.new(1,-8,0,0)
	else
		TargetChannelChip.Visible = true
		Textbox.Parent.Size = UDim2.new(1,-8-TargetChannelChip.AbsoluteSize.X,0,0)
		task.wait()
		Textbox.Text = ""
	end
end

TargetChannelChip.MouseButton1Click:Connect(function()
	ChangeChatStatus("All")
end)

Textbox.Focused:Connect(function()
	focused = true
	oc = os.clock()+3
	Textbox.PlaceholderText = ""
end)

Textbox.FocusLost:Connect(function()
	focused = false
	oc = os.clock()+3
	RunService.RenderStepped:Wait()
	dd.Visible = false
	Textbox.PlaceholderText = placeholderText
end)

local comma = '<font color="#b2b2b2">,</font>'
local ddd = '<font color="#b2b2b2">...</font>'
typingchange.OnClientEvent:Connect(function(player, typing)
	local found = table.find(peopleTypingRn, player)
	if not found and typing then
		table.insert(peopleTypingRn, player)
	elseif found and not typing then
		table.remove(peopleTypingRn, found)
	end

	local fixed = {}
	for _, player in peopleTypingRn do
		table.insert(fixed, player.DisplayName)
	end

	local success, error = pcall(function()
		if #peopleTypingRn > 3 then
			Typing.Text = (`%s{comma} %s{comma} %s{ddd} +{#peopleTypingRn-3} players <font color="#b2b2b2">are typing...</font>`):format(unpack(fixed))
		elseif #peopleTypingRn == 3 then
			Typing.Text = (`%s{comma} %s{comma} and %s <font color="#b2b2b2">are typing...</font>`):format(unpack(fixed))
		elseif #peopleTypingRn == 2 then
			Typing.Text = (`%s and %s <font color="#b2b2b2">are typing...</font>`):format(unpack(fixed))
		elseif #peopleTypingRn == 1 then
			Typing.Text = (`%s <font color="#b2b2b2">is typing...</font>`):format(unpack(fixed))
		else
			Typing.Text = `<font color="#b2b2b2">No one is typing.</font>`
		end
	end)
	if not success then
		Typing.Text = 'Several people <font color="#b2b2b2">are typing...</font>'
	end
end)

local lastColon = 0

local function getColons(text: string)
	return #text - #text:gsub(":", "")
end

local function findLastColon(text: string)
	local lastColon = text:reverse():find(":")
	lastColon = lastColon and #text - lastColon + 1 or 0
	return lastColon
end

Textbox:GetPropertyChangedSignal("Text"):Connect(function()
	if os.clock() < oc then
		if Textbox.Text == "" or muted then
			Textbox.TextTransparency = 0.5
			Textbox.TextStrokeTransparency = 0.5
			sendi.TextTransparency = 0.5
			typingchange:FireServer(false)
		else
			Textbox.TextTransparency = 0
			Textbox.TextStrokeTransparency = 0.5
			sendi.TextTransparency = 0
			if Textbox:IsFocused() then
				typingchange:FireServer(true)
			end
		end
	end
	Textbox.Text = Textbox.Text:sub(1,200)
	local len = #Textbox.Text
	local lastColonN = findLastColon(Textbox.Text)
	local bool = getColons(Textbox.Text)%2 == 0
	if Textbox.Text:sub(1,1) == "/" then
		commandautocomplete()
		local split = Textbox.Text:split(" ")
		if (split[1] == "/w" or split[1] == "/whisper") and split[2] then
			local player = GetPlayer(split[2])
			if player then
				ChangeChatStatus(`To {player.DisplayName}`, player)
			end
		end
	elseif lastColonN ~= 0 and lastColon == 0 then
		lastColon = lastColonN
	elseif lastColonN ~= 0 and lastColonN ~= lastColon and bool and lastColon ~= 0 then
		local emoji = EmojiList[Textbox.Text:sub(lastColon+1,lastColonN-1)]
		if emoji then
			RunService.RenderStepped:Wait()
			Textbox.Text = Textbox.Text:gsub(Textbox.Text:sub(lastColon,lastColonN), emoji.base)
		end
		lastColon = 0
		emojiautocomplete(lastColon)
	elseif lastColonN ~= 0 then
		emojiautocomplete(lastColon)
	elseif lastColonN == 0 and lastColon ~= 0 then
		lastColon = 0
		emojiautocomplete(lastColon)
	else
		local layout = uhh["$layout"]:Clone()
		uhh:ClearAllChildren()
		layout.Parent = uhh
		dd.Visible = false
		ddinfo = {}
		selected = nil
	end
end)

task.spawn(function()
	while task.wait() do
		if os.clock() > oc then
			if focused then
				oc = os.clock()+0.1
			else
				for i,v in pairs(Hide) do
					v:Play()
				end
				repeat task.wait() until os.clock() <= oc
				for i,v in pairs(Show) do
					v:Play()
				end
				TweenService:Create(Textbox, ShowInfo, {TextTransparency = (Textbox.Text == "" and 0.5 or 0), TextStrokeTransparency = CIBC.TextStrokeTransparency}):Play()
				TweenService:Create(sendi, ShowInfo, {TextTransparency = (Textbox.Text == "" and 0.5 or 0), TextStrokeTransparency = CIBC.TextStrokeTransparency}):Play()
			end
		end
	end
end)

task.spawn(function()
	while true do
		local s,b = pcall(function()
			return StarterGui:GetCore("ChatActive")
		end)
		if s and b and StarterGui:GetCoreGuiEnabled(Enum.CoreGuiType.Chat) then
			appLayout.Visible = true
		else
			appLayout.Visible = false
			oc = os.clock()+3
		end
		task.wait()
	end
end)

local sizey = 0

for _, gb in appLayout:GetChildren() do
	if gb:IsA("GuiObject") then
		sizey += gb.AbsoluteSize.Y
	end
end


for _, gb in appLayout:GetChildren() do
	if gb:IsA("GuiObject") then
		gb:GetPropertyChangedSignal("GuiState"):Connect(function()
			if gb.GuiState ~= Enum.GuiState.Idle then
				while gb.GuiState ~= Enum.GuiState.Idle do
					oc = os.clock()+3
					task.wait()
				end
			end
		end)
	end
end

UserInputService.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.Touch and (input.Position.X >= appLayout.AbsolutePosition.X and input.Position.X <= appLayout.AbsolutePosition.X+appLayout.AbsoluteSize.X) and (input.Position.Y >= appLayout.AbsolutePosition.Y and input.Position.Y <= appLayout.AbsolutePosition.Y+sizey) then
		oc = os.clock()+3
	end
end)

UserInputService.InputBegan:Connect(function(input, gpe)
	if selected then
		if input.KeyCode == Enum.KeyCode.Up and gpe then
			selectindex(selected-1)
		end
		if input.KeyCode == Enum.KeyCode.Down and gpe then
			selectindex(selected+1)
		end
	end
	if input.KeyCode == Enum.KeyCode.Space and gpe then
		if Textbox.Text:split(" ")[1] == "/team" and LocalPlayer.Team then
			ChangeChatStatus("Team")
		end
	end
	if input.KeyCode == Enum.KeyCode.Backspace then
		local whenCanRemove = os.clock()
		while input.UserInputState ~= Enum.UserInputState.End do
			if Textbox.Text ~= "" then
				whenCanRemove = os.clock()+.3
			end
			if cstatus == "All" then
				break
			end
			if Textbox.Text == "" and cstatus ~= "All" and os.clock()-whenCanRemove >= 0 then
				ChangeChatStatus("All")
				break
			end
			task.wait()
		end
	end
	if input.KeyCode == CIBC.KeyboardKeyCode and not gpe and not muted then
		StarterGui:SetCore("ChatActive", true)
		task.wait()
		Textbox:CaptureFocus()
	end
end)

local function browhatuse()
	local te, ke, me = UserInputService.TouchEnabled, UserInputService.KeyboardEnabled, UserInputService.MouseEnabled
	if te and ke and me then
		return "To chat click/tap here or press / key"
	elseif te and ke and not me then
		return "To chat tap here or press / key"
	elseif te and not ke and me then
		return "To chat click or tap here"
	elseif te and not ke and not me then
		return "To chat tap here"
	elseif not te and ke and me then
		return "To chat click here or press / key"
	elseif not te and ke and not me then
		return "To chat press / key"
	elseif not te and not ke and me then
		return "To chat click here"
	elseif not te and not ke and not me then
		return "Bro can you even do something?"
	end
end

local function change(p)
	if p == "TouchEnabled" or p == "KeyboardEnabled" or p == "MouseEnabled" or p == "justchangeitbro" then
		placeholderText = browhatuse()
		if not Textbox:IsFocused() then
			Textbox.PlaceholderText = placeholderText
		end
	end
end

UserInputService.Changed:Connect(change)
change("justchangeitbro")

local rtc = RCTScrollContentView
local oldsize = rtc.AbsoluteSize
RunService.Heartbeat:Connect(function()
	if rtc.AbsoluteSize ~= oldsize then
		local m = rtc.AbsoluteSize.Y-oldsize.Y
		m = m < 0 and m*-1 or m
		rtc.Parent.CanvasPosition = Vector2.new(rtc.Parent.CanvasPosition.X, rtc.Parent.CanvasPosition.Y+m)
		oldsize = rtc.AbsoluteSize
	end

	if muted then
		if Textbox.Interactable then
			if os.clock() < oc then
				Textbox.TextTransparency = 0.5
				sendi.TextTransparency = 0.5
			end
			Textbox.Interactable = false
			Textbox.Text = `{muted.Mins and "Temporary muted" or "Muted"} by {muted.Admin}`
		end
		if appLayout.inputBar.Visible then
			appLayout.inputBar.Visible = false
		end
	else
		if not Textbox.Interactable then
			Textbox.Text = ""
			Textbox.Interactable = true
		end
		if appLayout.inputBar.Visible ~= CIBC:GetAttribute("CustomEnabled") then
			appLayout.inputBar.Visible = CIBC:GetAttribute("CustomEnabled")
		end
	end
end)

local function send()
	if Textbox.Interactable then
		local message = Textbox.Text
		Textbox.Text = ""
		task.delay(0.001, function()
			Textbox.Text = ""
		end)
		if isCmd(message) then
			execCmd(message)
			return
		end
		clientsend(message)
	end
end

sendi.Parent.MouseButton1Click:Connect(send)

Textbox.FocusLost:Connect(function(enterr)
	if enterr then
		if Textbox.Text:split(" ")[1] == "/team" and LocalPlayer.Team then
			ChangeChatStatus("Team")
			RunService.RenderStepped:Wait()
			Textbox:CaptureFocus()
			return
		end
		if selected then
			enter(lastColon, ddinfo[selected][3])
			RunService.RenderStepped:Wait()
			Textbox:CaptureFocus()
			return
		end
		send()
	end
end)

TextChatService:WaitForChild("NOTRBXGeneral"):DisplaySystemMessage(`Type '/?' or '/help' for a list of chat commands`, "d4d4d4")
RunService.RenderStepped:Wait()
while not UserInputService.TouchEnabled or UserInputService.KeyboardEnabled do
	RunService.RenderStepped:Wait()
end
TextChatService:WaitForChild("NOTRBXGeneral"):DisplaySystemMessage(`WARNING! Some features may not work properly on your device`, "f74b52")