shared.ExpChatRemake = {}

local game = game

shared.ExpChatRemake.Mutes = {}
local Players = game:GetService("Players")
local TextChatService = game:GetService("TextChatService")
local TextService = game:GetService("TextService")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local EncodingService = game:GetService("EncodingService")
local MarketplaceService = game:GetService("MarketplaceService")
local MessagingService = game:GetService("MessagingService")
local Remotes = Instance.new("Folder")
local Modules = script.Modules:Clone()
local Update = Instance.new("RemoteFunction", Remotes)
local Ping = Instance.new("RemoteFunction", Remotes)
local Success = Instance.new("BindableEvent", Remotes)
local History = Instance.new("BindableFunction", Remotes)
local Event = Instance.new("RemoteEvent", Remotes)
local StatusChanged = Instance.new("RemoteEvent", Remotes)
local DisplaySystem = Instance.new("RemoteEvent", Remotes)
local Display = Instance.new("BindableEvent", Remotes)
local CreateUI = Instance.new("RemoteFunction", Remotes)
local TypingChanged = Instance.new("UnreliableRemoteEvent", Remotes)
Instance.new("BindableEvent", Remotes).Name = "Fire"
local Creators = {}
local Handler = script.Handler
local UI = script.Experience
local NOTRBXGeneral: TextChannel = Instance.new("TextChannel", TextChatService)
local PlayersChat = {}
local HistoryList = {
	Msg = {},
	Sign = {}
}
local PlayersMute = {}
local PlayersVip = {}
local PlayersTyping = {}
local ExpChatCreators = game.PlaceId ~= 0 and game:GetService("DataStoreService"):GetDataStore("ExpChatCreators")
local code = require(ReplicatedStorage:WaitForChild("Code"))
local encode = code.encode
local decode = code.decode

task.spawn(function()
	shared.ExpChatRemake.TempMute = function(who, userid, reason, when)
		shared.ExpChatRemake.Mutes[userid] = {
			Admin = who,
			Reason = reason,
			Mins = when
		}
		while shared.ExpChatRemake.Mutes[userid] and (os.clock()+when*60)-os.clock() > 0 do
			task.wait()
		end
		shared.ExpChatRemake.Mutes[userid] = false
	end

	shared.ExpChatRemake.Mute = function(who, userid, reason)
		shared.ExpChatRemake.Mutes[userid] = {
			Admin = who,
			Reason = reason
		}
	end

	local function call(...)
		Display:Fire(...)
	end

	shared.ExpChatRemake.Global = function(text, mt)
		MessagingService:PublishAsync("Global", {t = text, m = mt})
	end

	shared.ExpChatRemake.Server = function(text, mt)
		call("all", '[Server]: '..text, mt or "")
	end

	MessagingService:SubscribeAsync("Global", function(m)
		call("all", '[Global]: '..m.Data.t, m.Data.m or "")
	end)
end)

local function r()
	local char = string.char(math.random(32, 126))
	while char == '+' or char == '{' or char == "}" or char == "[" or char == "]" do
		return r()
	end
	return char
end

local function generateCodeTable()
	local l = 5
	local ct = {}
	for i = 1,255,1 do
		local c = string.char(i)
		ct[c] = ""
		for _ = 1,l do
			ct[c] ..= r()
		end
	end
	return ct,l
end

local codeTable, length = generateCodeTable()

code.setCodeTable(codeTable, length)

if TextChatService.CreateDefaultTextChannels then
	warn("You need to disable 'TextChatService.CreateDefaultTextChannels' to make script work")
	return
end

-- does some things
task.spawn(function()
	pcall(function()
		TextChatService:WaitForChild("ChatWindowConfiguration"):SetAttribute("CustomEnabled", true)
		TextChatService:WaitForChild("ChatInputBarConfiguration"):SetAttribute("CustomEnabled", true)
	end)
end)

-- hide ts from roblox server lol
script.Parent = nil

local WHITESPACES = {
	"\n\r\t\v\f",
	{
		["\n"] = " ",
		["\r"] = " ",
		["\t"] = " ",
		["\v"] = " ",
		["\f"] = " "
	},
	{
		["\n"] = "\\n",
		["\r"] = "\\r",
		["\t"] = "\\t",
		["\v"] = "\\v",
		["\f"] = "\\f"
	}
}
local REPLACE = {
	`&<>"'`,
	{
		["&"] = "&amp;",
		["<"] = "&lt;",
		[">"] = "&gt;",
		['"'] = '&quot;',
		["'"] = '&apos;',
	}
}

Remotes.Name = "Remotes"
Update.Name = "Update"
Ping.Name = "Ping"
History.Name = "History"
Event.Name = "Event"
StatusChanged.Name = "StatusChanged"
DisplaySystem.Name = "DisplaySystem"
CreateUI.Name = "CreateUI"
Display.Name = "Display"
Success.Name = "Success"
TypingChanged.Name = "TypingChanged"

Remotes.Parent = ReplicatedStorage
Modules.Parent = ReplicatedStorage
Handler.Parent = game:GetService("TestService")
Handler.Enabled = true
NOTRBXGeneral.Name = "NOTRBXGeneral"

NOTRBXGeneral.ShouldDeliverCallback = function(message, textsource)
	return
end

local function StartAntiFlood(player)
	pcall(function()
		PlayersChat[player].Time = 10
		while PlayersChat[player].Time > 0 do
			task.wait(1)
			PlayersChat[player].Time -= 1
		end
		PlayersChat[player] = {
			Messages = 0,
			Time = 0 
		}
	end)
end

local function GetFilterResult(text, fromUserId)
	local filterResult
	local success, errorMessage = pcall(function()
		filterResult = TextService:FilterStringAsync(text, fromUserId)
	end)

	if success then
		return filterResult
	else
		--warn("Error generating TextFilterResult:", errorMessage)
		return nil
	end
end

local function RemoveSlop(text)
	return text:gsub("[%p%c]+", ""):gsub("[%s]+", " ")
end

local function CheckMessage(text)
	text = text:gsub(`[{WHITESPACES[1]}]`, WHITESPACES[2])
	text = text:gsub('<([%w%s="\'`()#/]+)>', ''):gsub('%%([%w%s="\'`()#/]+);', '')
	local text = text:split(" ")
	local whatrm = {}
	for index, _ in text do
		if text[index] == "" then
			whatrm[#whatrm+1] = index
		end
	end
	local lol = 0
	for _, index in whatrm do
		table.remove(text, index-lol)
		lol += 1
	end
	return table.concat(text, " ")
end

local function Replace(text)
	text = text:gsub(`[{REPLACE[1]}]`, REPLACE[2])
	return text
end

local function HowThisCanBeDisplayed(message, player)
	message = CheckMessage(message)
	if message == "" or message:gsub(" ", "") == "" then
		return
	end
	local unfiltered = message
	local messagenoslop = RemoveSlop(message)
	local tmp = messagenoslop
	local FilterResult1 = GetFilterResult(messagenoslop, player.UserId)
	local FilterResult2 = GetFilterResult(message, player.UserId)
	local s1,_ = pcall(function()
		messagenoslop = FilterResult1:GetNonChatStringForBroadcastAsync()
	end)
	local s2,_ = pcall(function()
		message = FilterResult2:GetNonChatStringForBroadcastAsync()
	end)
	if not s1 or not s2 or messagenoslop ~= tmp then
		message = table.concat(table.create(#message, "#"), "")
	end
	if message:find("roblox") and (message:find("www") or message:find("com")) then
		message = table.concat(table.create(#message, "#"), "")
	end
	if message ~= unfiltered then
		unfiltered ..= " [FILTERED]"
	end
	if #message > 200 then
		return
	end
	message = Replace(message)
	return unfiltered, message
end

local function GetPlayer(playerReq: Player, name: string)
	if name then
		name = name:lower()
		local players = {}
		for _, player in Players:GetPlayers() do
			if player == playerReq then continue end
			if player.DisplayName:lower():sub(1,name:len()) == name or player.Name:lower():sub(1,name:len()) == name then
				players[#players+1] = player
			end
		end
		print(players)
		return #players == 1 and players[1] or #players > 1 and players
	else
		return
	end
end

local function ReplaceCommand(OG: TextChatCommand, Name: string, Function)
	local Custom = OG:Clone()
	Custom.Triggered:Connect(Function or function(...) return ... end)
	Custom.Name = Name
	Custom.Parent = OG.Parent
	OG:Destroy()
end

local function CreateCommand(Name: string, Where: Instance, PrimaryAlias: string, SecondaryAlias: string, Function)
	local Command = Instance.new("TextChatCommand")
	Command.PrimaryAlias = PrimaryAlias
	Command.SecondaryAlias = SecondaryAlias
	Command.Triggered:Connect(Function or function(...) return ... end)
	Command.Name = Name
	Command.Parent = Where
end

local function fix(text)
	if text and typeof(text) == "string" and text:sub(1,1) == " " then
		return text:sub(2)
	end
	return text
end

task.spawn(function()
	pcall(function()
		ReplaceCommand(TextChatService:WaitForChild("TextChatCommands"):WaitForChild("RBXTeamCommand"), "RBXCustomTeamCommand", function(ts: TextSource, text)
			local player = Players:GetPlayerByUserId(ts.UserId)
			local team = player.Team
			local message = table.concat(text:split(" "), " ", 2)
			if player and team and message then
				if shared.ExpChatRemake.Mutes[player.UserId] then
					DisplaySystem:FireClient(player, encode(`<font color="#f74b52">You're currenly muted by '{shared.ExpChatRemake.Mutes[player.UserId].Admin}' reason: '{shared.ExpChatRemake.Mutes[player.UserId].Reason}'</font>`))
					return
				end
				if PlayersChat[player].Messages >= 5 then
					DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">You must wait before sending another message.</font>`))
					return
				end
				local unfiltered, message = HowThisCanBeDisplayed(message, player)
				if not unfiltered or not message then
					return
				end
				if PlayersChat[player].Messages == 0 then
					PlayersChat[player].Messages += 1
					task.spawn(StartAntiFlood, player)
				else
					PlayersChat[player].Messages += 1
					PlayersChat[player].Time += 1
				end
				for _, playerr in team:GetPlayers() do
					if not table.find(PlayersMute[player.UserId], playerr) then
						Event:FireClient(playerr, encode(player.Name), encode(message), nil, team, player:GetAttribute("IconInChat"))
					end
				end
				Success:Fire(player, unfiltered, team)
			else
				if player and message and not team then
					DisplaySystem:FireClient(player, encode('<font color="#f74b52">You cannot team chat if you are not on a team.</font>'))
				end
			end
		end)

		ReplaceCommand(TextChatService:WaitForChild("TextChatCommands"):WaitForChild("RBXWhisperCommand"), "RBXCustomWhisperCommand", function(ts: TextSource, text)
			local player = Players:GetPlayerByUserId(ts.UserId)
			local player2 = GetPlayer(player, text:split(" ")[2])
			local message = table.concat(text:split(" "), " ", 3)
			if player and player2 then
				if typeof(player2) == "table" then
					DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">There are {#player2} players with similar name: {table.concat(player2, ", ")}</font>`))
					return
				end
				if shared.ExpChatRemake.Mutes[player.UserId] then
					DisplaySystem:FireClient(player, encode(`<font color="#f74b52">You're currenly muted by '{shared.ExpChatRemake.Mutes[player.UserId].Admin}' reason: '{shared.ExpChatRemake.Mutes[player.UserId].Reason}'</font>`))
					return
				end
				if PlayersChat[player].Messages >= 5 then
					DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">You must wait before sending another message.</font>`))
					return
				end
				local unfiltered, message = HowThisCanBeDisplayed(message, player)
				if not unfiltered or not message then
					return
				end
				if PlayersChat[player].Messages == 0 then
					PlayersChat[player].Messages += 1
					task.spawn(StartAntiFlood, player)
				else
					PlayersChat[player].Messages += 1
					PlayersChat[player].Time += 1
				end
				if typeof(player2) == "Instance" and player2:IsA("Player") then
					Event:FireClient(player, encode(player.Name), encode(message), encode(player2.Name), nil, player:GetAttribute("IconInChat"))
					if not table.find(PlayersMute[player.UserId], player2) then
						Event:FireClient(player2, encode(player.Name), encode(message), encode(player2.Name), nil, player:GetAttribute("IconInChat"))
					end
					Success:Fire(player, unfiltered, player2)
				else
					DisplaySystem:FireClient(player, encode('<font color="#f74b52">Failed to whisper player</font>'))
				end
			else
				if player and not player2 then
					DisplaySystem:FireClient(player, encode(`<font color="#f74b52">User '{text:split(" ")[2]}' does not exist.</font>`))
				end
			end
		end)

		ReplaceCommand(TextChatService:WaitForChild("TextChatCommands"):WaitForChild("RBXHelpCommand"), "RBXCustomHelpCommand")

		ReplaceCommand(TextChatService:WaitForChild("TextChatCommands"):WaitForChild("RBXMuteCommand"), "RBXCustomMuteCommand", function(ts: TextSource, text)
			local player = Players:GetPlayerByUserId(ts.UserId)
			local player2 = GetPlayer(player, text:split(" ")[2])
			if player and player2 then
				if typeof(player2) == "table" then
					DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">There are {#player2} players with similar name: {table.concat(player2, ", ")}</font>`))
					return
				end
				if player == player2 then
					return
				end
				local index = table.find(PlayersMute[player2.UserId], player)
				if index then
					DisplaySystem:FireClient(player, encode('<font color="#d4d4d4">Player is already muted</font>'))
				else
					table.insert(PlayersMute[player2.UserId], player)
				end
			else
				if player and not player2 then
					DisplaySystem:FireClient(player, encode(`<font color="#f74b52">User '{text:split(" ")[2]}' does not exist.</font>`))
				end
			end
		end)

		ReplaceCommand(TextChatService:WaitForChild("TextChatCommands"):WaitForChild("RBXUnmuteCommand"), "RBXCustomUnmuteCommand", function(ts: TextSource, text)
			local player = Players:GetPlayerByUserId(ts.UserId)
			local player2 = GetPlayer(player, text:split(" ")[2])
			if player and player2 then
				if typeof(player2) == "table" then
					DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">There are {#player2} players with similar name: {table.concat(player2, ", ")}</font>`))
					return
				end
				if player == player2 then
					return
				end
				local index = table.find(PlayersMute[player2.UserId], player)
				if index then
					table.remove(PlayersMute[player2.UserId], index)
				else
					DisplaySystem:FireClient(player, encode('<font color="#d4d4d4">Player is not muted</font>'))
				end
			else
				if player and not player2 then
					DisplaySystem:FireClient(player, encode(`<font color="#f74b52">User '{text:split(" ")[2]}' does not exist.</font>`))
				end
			end
		end)
		
		local chat_version = `{script.Name}.server.lua (made by @GAMECHATLOGGER, aka @CameraAttachment)`
		ReplaceCommand(TextChatService:WaitForChild("TextChatCommands"):WaitForChild("RBXVersionCommand"), "RBXCustomVersionCommand", function(ts: TextSource)
			local player = Players:GetPlayerByUserId(ts.UserId)
			if player then
				DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">{chat_version}</font>`))
			end
		end)
	end)
	
	CreateCommand("NOTRBXServerMuteCommand", TextChatService:WaitForChild("TextChatCommands"), "/servermute", "/sm", function(ts: TextSource, text)
		local player = Players:GetPlayerByUserId(ts.UserId)
		local split = text:split(";")	
		local player2 = GetPlayer(player, split[1]:split(" ")[2])
		local reason, mins = fix(split[2]), fix(split[3])
		if player and player2 then
			if typeof(player2) == "table" then
				DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">There are {#player2} players with similar name: {table.concat(player2, ", ")}</font>`))
				return
			end
			if player == player2 then
				return
			end
			if not Creators[player.UserId] then
				return
			end
			if Creators[player2.UserId] == "<b>hammer-code</b>" or Creators[player2.UserId] == "<b>gear</b>" then
				DisplaySystem:FireClient(player, encode(`<font color="#f74b52">Can't mute player '{player2.DisplayName}'.</font>`))
				return
			end
			if shared.ExpChatRemake.Mutes[player2.UserId] then
				DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">'{player2.DisplayName}' is already muted</font>`))
			else
				if mins then
					shared.ExpChatRemake.TempMute(player.DisplayName, player2.UserId, reason, mins)
				else
					shared.ExpChatRemake.Mute(player.DisplayName, player2.UserId, reason)
				end
				DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">Successfully muted '{player2.DisplayName}'</font>`))
			end
		else
			if player and not player2 then
				DisplaySystem:FireClient(player, encode(`<font color="#f74b52">Player '{text:split(" ")[2]:sub(1,-2)}' does not exist.</font>`))
			end
		end
	end)

	CreateCommand("NOTRBXServerUnmuteCommand", TextChatService:WaitForChild("TextChatCommands"), "/serverunmute", "/sum", function(ts: TextSource, text)
		local player = Players:GetPlayerByUserId(ts.UserId)
		local player2 = GetPlayer(player, text:split(" ")[2])
		if player and player2 then
			if typeof(player2) == "table" then
				DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">There are {#player2} players with similar name: {table.concat(player2, ", ")}</font>`))
				return
			end
			if player == player2 then
				return
			end
			if not Creators[player.UserId] then
				return
			end
			if Creators[player2.UserId] == "<b>hammer-code</b>" or Creators[player2.UserId] == "<b>gear</b>" then
				DisplaySystem:FireClient(player, encode(`<font color="#f74b52">Can't unmute player '{player2.DisplayName}'.</font>`))
				return
			end
			if shared.ExpChatRemake.Mutes[player2.UserId] then
				shared.ExpChatRemake.Mutes[player2.UserId] = false
				DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">Successfully unmuted '{player2.DisplayName}'</font>`))
			else
				DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">'{player2.DisplayName}' is not muted</font>`))
			end
		else
			if player and not player2 then
				DisplaySystem:FireClient(player, encode(`<font color="#f74b52">Player '{text:split(" ")[2]}' does not exist.</font>`))
			end
		end
	end)
	
	CreateCommand("NOTRBXSitCommand", TextChatService:WaitForChild("TextChatCommands"), "/sit", "", function(ts: TextSource)
		local player = Players:GetPlayerByUserId(ts.UserId)
		if player then
			local character = player.Character
			if character then
				local humanoid = character:FindFirstChild("Humanoid")
				if humanoid then
					humanoid.Sit = true
				end
			end
		end
	end)
end)

Update.OnServerInvoke = function(player, message)
	message = decode(message)
	if shared.ExpChatRemake.Mutes[player.UserId] then
		DisplaySystem:FireClient(player, encode(`<font color="#f74b52">You're currenly muted by '{shared.ExpChatRemake.Mutes[player.UserId].Admin}' reason: '{shared.ExpChatRemake.Mutes[player.UserId].Reason}'</font>`))
		return
	end
	if PlayersChat[player].Messages >= 5 then
		DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">You must wait before sending another message.</font>`))
		return
	end
	local unfiltered, message = HowThisCanBeDisplayed(message, player)
	if not unfiltered or not message then
		return
	end
	if PlayersChat[player].Messages == 0 then
		PlayersChat[player].Messages += 1
		task.spawn(StartAntiFlood, player)
	else
		PlayersChat[player].Messages += 1
		PlayersChat[player].Time += 1
	end
	for _, playerr in Players:GetPlayers() do
		if not table.find(PlayersMute[player.UserId], playerr) then
			Event:FireClient(playerr, encode(player.Name), encode(message), nil, nil, player:GetAttribute("IconInChat"))
		end
	end
	Success:Fire(player, unfiltered)
	return true
end

Ping.OnServerInvoke = function(player, message)
	message = decode(message)
	return HowThisCanBeDisplayed(message, player)
end

Success.Event:Connect(function(player, message, pot, sign)
	local prefix = player.Name
	if pot then
		if pot:IsA("Team") then
			prefix = `[Team {pot.Name}] {prefix}`
		elseif pot:IsA("Player") then
			prefix = `[To {pot.Name}] {prefix}`
		end
	end
	table.insert(HistoryList, `{prefix}: {message}`)
	if #HistoryList > 67108864 then
		table.remove(HistoryList, 1)
	end
end)

History.OnInvoke = function()
	return HistoryList
end

Display.Event:Connect(function(player, message, mt)
	if player:lower() == "all" then
		DisplaySystem:FireAllClients(encode(message), encode(mt))
	else
		player = GetPlayer(player)
		if typeof(player) == "Instance" and player:IsA("Player") then
			DisplaySystem:FireClient(player, encode(message), encode(mt))
		end
	end
end)

local function ReplicateTyping(player, typing, specific)
	if specific then
		if not (PlayersMute[specific.UserId] and table.find(PlayersMute[specific.UserId], player)) then
			TypingChanged:FireClient(specific, player, typing)
		end
	else
		for _, playerr in Players:GetPlayers() do
			if not (PlayersMute[playerr.UserId] and table.find(PlayersMute[playerr.UserId], player)) then
				TypingChanged:FireClient(playerr, player, typing)
			end
		end
	end
end

TypingChanged.OnServerEvent:Connect(function(player, typing)
	if not shared.ExpChatRemake.Mutes[player.UserId] then
		if typing then
			if PlayersTyping[player] then
				PlayersTyping[player].LastType = os.clock()
			else
				PlayersTyping[player] = {
					LastType = os.clock()
				}
				PlayersTyping[player].Connection = RunService.Heartbeat:Connect(function()
					if os.clock() - PlayersTyping[player].LastType > 5 then
						PlayersTyping[player].Connection:Disconnect()
						PlayersTyping[player] = nil
						ReplicateTyping(player, false)
					end
				end)
				ReplicateTyping(player, typing)
			end
		else
			if PlayersTyping[player] then
				PlayersTyping[player].Connection:Disconnect()
				PlayersTyping[player] = nil
				ReplicateTyping(player, typing)
			end
		end
	end
end)

Players.PlayerAdded:Connect(function(player)
	player:SetAttribute("CantDoAnything", true)
	if game.PrivateServerOwnerId == player.UserId then
		Creators[player.UserId] = `<b>circle-star</b>`
	end
	local function alt()
		local success, icon = pcall(function()
			return ExpChatCreators:GetAsync(player.UserId)
		end)
		while not success do
			task.wait(1)
			success, icon = pcall(function()
				return ExpChatCreators:GetAsync(player.UserId)
			end)
		end
		if icon then
			Creators[player.UserId] = icon
		end
	end
	task.spawn(pcall, function()
		ReplicatedStorage.giveclient:InvokeClient(player, codeTable, length)
	end)
	PlayersChat[player] = {
		Messages = 0,
		Time = 0 
	}
	PlayersMute[player.UserId] = {}
	NOTRBXGeneral:AddUserAsync(player.UserId)
	if ExpChatCreators and game.PlaceId ~= 0 then
		if game.CreatorType == Enum.CreatorType.User then
			if game.CreatorId == player.UserId then
				Creators[player.UserId] = `<b>hammer-code</b>`
			else
				alt()
			end
		else
			if player:GetRankInGroupAsync(game.CreatorId) >= 254 then
				Creators[player.UserId] = `<b>hammer-code</b>`
			else
				alt()
			end
		end
	else
		Creators[player.UserId] = `<b>hammer-code</b>`
	end
	if not player.Character then
		player.CharacterAdded:Wait()
	end
	player:SetAttribute("CanAddChatTime", os.clock())
	player:SetAttribute("IconInChat", Creators[player.UserId])
	player:SetAttribute("CantDoAnything", nil)
end)

Players.PlayerRemoving:Connect(function(player)
	PlayersChat[player] = nil
	PlayersMute[player.UserId] = nil
	Creators[player.UserId] = nil
end)

CreateUI.OnServerInvoke = function(player)
	local playergui = player:FindFirstChild("PlayerGui")
	local UII = nil
	if playergui and os.clock()-(player:GetAttribute("CanAddChatTime") or 1/0) > -.1 then
		player:SetAttribute("CanAddChatTime", nil)
		UII = UI:Clone()
		UII.Parent = player.PlayerGui
		task.delay(0.5, function()
			StatusChanged:FireClient(player, PlayersMute[player])
			for _, playerr in PlayersTyping do
				ReplicateTyping(playerr, true, player)
			end
		end)
	end
	return UII
end

local Mutes = table.clone(shared.ExpChatRemake.Mutes)
while task.wait(0.1) do
	for playeruserid, status in shared.ExpChatRemake.Mutes do
		local player = Players:GetPlayerByUserId(playeruserid)
		if player then
			if typeof(Mutes[player.UserId]) ~= typeof(status) then
				if status then
					DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">You got {status.Mins and "temporary muted" or "muted"} by '{status.Admin}'{status.Reason and `, reason: '{status.Reason}'` or ""}</font>`))
				else
					DisplaySystem:FireClient(player, encode(`<font color="#d4d4d4">You got unmuted</font>`))
				end
				StatusChanged:FireClient(player, status)
			end
		end
		Mutes[playeruserid] = status
	end
end